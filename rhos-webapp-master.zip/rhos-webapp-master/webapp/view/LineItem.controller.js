sap.ui.controller("jerrylist.view.LineItem", {

	handleNavBack : function (evt) { 
		this.nav.back("Detail");
	}
});